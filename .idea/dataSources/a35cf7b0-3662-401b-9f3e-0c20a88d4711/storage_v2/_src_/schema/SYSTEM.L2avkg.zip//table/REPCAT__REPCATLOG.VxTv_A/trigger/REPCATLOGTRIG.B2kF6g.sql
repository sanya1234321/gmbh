CREATE TRIGGER REPCATLOGTRIG
  AFTER UPDATE OR DELETE
  ON REPCAT$_REPCATLOG
  BEGIN
  sys.dbms_alert.signal('repcatlog_alert', '');
END;
/

